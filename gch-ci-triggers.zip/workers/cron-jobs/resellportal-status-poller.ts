/**
 * ResellPortal has no status webhooks — it's documented as request-only.
 * This worker polls GET /services on an interval and reconciles
 * deployment_status ("installing" -> "deployed") and next_billing_date
 * against local orchestration state.
 *
 * Scheduling: run this from something that supports sub-5-minute
 * intervals if you need near-real-time provisioning status — Hostinger
 * cPanel cron, a systemd timer on a VPS, or a queue-based worker.
 * GitHub Actions `schedule` is only wired up here as a throttled
 * fallback/health-check (see resellportal-poll-fallback.yml); it is not
 * guaranteed to run at the requested minute.
 *
 * Authority boundary (Phase 6/11): this worker OBSERVES and forwards
 * state. It must never itself declare a service "provisioned" locally —
 * that determination flows through the authoritative resolver and the
 * approved entitlement state machine.
 */

const RESELLPORTAL_BASE_URL = 'https://panel.resellportal.com/wp-json/resellportal/v1/';

interface ResellPortalService {
  id: string;
  client_id: string;
  deployment_status: 'installing' | 'deployed' | string;
  next_billing_date: string;
  [key: string]: unknown;
}

async function pollResellPortalServices(apiKey: string): Promise<ResellPortalService[]> {
  const res = await fetch(`${RESELLPORTAL_BASE_URL}services`, {
    method: 'GET',
    headers: { 'X-API-Key': apiKey },
  });

  if (!res.ok) {
    throw new Error(`ResellPortal GET /services returned ${res.status}: ${await res.text()}`);
  }

  return res.json();
}

export async function reconcileProvisioningStatus(): Promise<ResellPortalService[]> {
  const apiKey = process.env.RESELLPORTAL_API_KEY;
  if (!apiKey) {
    throw new Error('RESELLPORTAL_API_KEY is not set.');
  }

  const services = await pollResellPortalServices(apiKey);

  for (const service of services) {
    // TODO (Phase 6/11): route each service through the authoritative
    // resolver + approved entitlement states instead of logging. Do not
    // write "provisioned" locally on the strength of deployment_status
    // alone — ResellPortal remains the fulfillment/provisioning
    // authority; this worker forwards, it does not declare.
    console.log(
      `[resellportal-poll] service=${service.id} client=${service.client_id} ` +
        `status=${service.deployment_status} next_billing=${service.next_billing_date}`,
    );
  }

  return services;
}

if (require.main === module) {
  reconcileProvisioningStatus().catch((err) => {
    console.error(err);
    process.exit(1);
  });
}
