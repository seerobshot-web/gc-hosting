# GCH Remainder Implementation — CI/CD Triggers

## Direct answer

"Trigger," "cron job," "webhook," and "action" name three genuinely different mechanisms, and conflating them is where these builds usually go sideways. What follows separates them and gives you a working file for each:

- **GitHub Actions workflows** — orchestrate *this refactor itself*: build/test/audit gates per phase, a required human/Codex approval before merge, disposable-database dry runs, and a gated production deploy. These are the files under `.github/workflows/`.
- **A real webhook** — only one exists in this system: Stripe calling your API directly over HTTPS. That's application code in `apps/api`, not a GitHub trigger. See `apps/api/src/webhooks/stripe.webhook.controller.ts`.
- **A poller standing in for a webhook that doesn't exist** — ResellPortal's documented contract is request-only with no status callbacks, so "when did provisioning finish" has to be answered by polling `GET /services`. See `workers/cron-jobs/resellportal-status-poller.ts`, with a GitHub Actions fallback that is explicitly *not* the primary mechanism.

None of these files touch your production database or Stripe/ResellPortal accounts by default — every step that could is placed behind a GitHub Environment requiring a named reviewer's approval, matching the plan's own "decision owners by role" and "explicitly approved" language.

## Deep dive — what each file does and which phase it closes

**`.github/workflows/phase-gate.yml`** — runs on every PR into `main`/`develop`. First job runs lint, typecheck, test, build, and `pnpm audit` across the Turborepo — the automated half of every phase's exit gate. Second job, `codex-review-gate`, sits behind the `phase-gate` GitHub Environment: it only executes once a required reviewer approves, and that approval is where you record that the Codex review prompt was actually run against the diff and returned "ready," not just that CI is green. Add `codex-review-gate` as a required status check in branch protection or this doesn't actually block a merge — GitHub Environments gate the *job*, branch protection is what gates the *merge button*.

**`.github/workflows/codeql.yml`** — the "applicable CodeQL" line item in every phase's exit gate and Phase 12's required review. Runs on push, PR, and a weekly schedule.

**`.github/workflows/migration-dry-run.yml`** — Phase 5. `workflow_dispatch` only, spins up a throwaway `mysql:8.0` service container (never a Hostinger database), applies the candidate migration, captures the generated SQL as an artifact, and attempts a rollback. Gated by the `migration-review` environment. One open decision this file can't paper over: your schema layer is recorded as "Prisma/Drizzle" — Prisma has no native down-migrations, so if you land on Prisma, "rollback owner" and "rollback limitations" (both already required inputs in Phase 5) need an answer before this workflow's rollback step means anything.

**`.github/workflows/backfill-dry-run.yml`** — Phase 7. Scheduled + manual, runs your bounded read-only scanner against `secrets.STAGING_DATABASE_URL` only. A guard step refuses to run if that URL is empty or contains `gloryhost.cloud`, so a copy-paste secret error can't point it at production. Gated by `backfill-dry-run` environment. This orchestrates the scanner; the bounded-cursor, no-writes, stop-condition logic itself still has to live in the script it calls (`workers-cron-jobs backfill:dry-run`).

**`.github/workflows/deploy.yml`** — the production side-effect gate from the squash-and-merge protocol. Fires on push to `main`, builds all three apps, then requires approval on the `production` environment before deploying anything. The three deploy steps are stubs — `deploy:hostinger` package scripts don't exist yet, and shouldn't be invented here; they're Phase 10's job once the pinned `@hostinger/sdk@1.54.1` adapter is real.

**`.github/workflows/resellportal-poll-fallback.yml`** + **`workers/cron-jobs/resellportal-status-poller.ts`** — because ResellPortal has no webhooks, "trigger" for provisioning status can only mean polling. The worker script hits `GET /services` with the documented `X-API-Key` header and logs `deployment_status`/`next_billing_date` — it deliberately does *not* write "provisioned" locally, because ResellPortal remains the fulfillment authority per your plan's boundary rules. The GitHub Actions version is a fallback health-check only: scheduled Actions runs are throttled by GitHub and commonly slip 10–60 minutes on low-activity repos, so it's the wrong tool for anything time-sensitive. Real provisioning-status polling belongs on Hostinger cPanel cron or a systemd timer calling the same worker function on a tight interval.

**`apps/api/src/webhooks/stripe.webhook.controller.ts`** — the one real webhook. Verifies the Stripe signature and fails closed on a bad signature, per Phase 10's "never accept browser success callbacks as payment authority" rule. Still missing before it's trustworthy: a real idempotency store keyed on `event.id`, and the actual routing into your Phase 11 entitlement state machine. Treat it as a starting skeleton, not a merge-ready adapter — that routing needs your real Prisma/Drizzle models, which weren't available to write against here.

## Practical application — getting this running

1. **Copy the folders in, don't overwrite blindly.** These paths mirror `gc-hosting-platform`'s existing layout (`apps/web`, `apps/portal`, `apps/api`, `workers/cron-jobs`) — merge them in rather than replacing anything that already exists there.
2. **Create the GitHub Environments** (Settings → Environments): `phase-gate`, `migration-review`, `backfill-dry-run`, `resellportal-poll`, `production`. For each, add the required reviewers who match the "decision owners by role" your plan already names — the resolver owner, migration owner, rollback owner, backfill owner, monitoring owner, and whoever signs off on deploys.
3. **Add branch protection** on `main` (and `develop` if you use it): require the `automated-checks` and `codex-review-gate` status checks before merge is allowed.
4. **Add secrets** (Settings → Secrets and variables → Actions): `STAGING_DATABASE_URL`, `PRODUCTION_DATABASE_URL`, `HOSTINGER_API_TOKEN`, `RESELLPORTAL_API_KEY`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`. Leave `CODEX_API_KEY` out until you actually have a Codex API endpoint to call — the commented-out step in `phase-gate.yml` is there for when you do.
5. **First run, low stakes:** trigger `migration-dry-run.yml` manually against a no-op migration once `packages/database` has `migrate:deploy`/`migrate:diff` scripts, just to confirm the ephemeral MySQL container and artifact upload work before you point it at anything from the 28-pair matrix.
6. **Everything with a TODO comment is intentionally unfinished** — those mark exactly the points where the plan itself requires an approved contract, owner, or adapter that wasn't available to inspect here, per its own "do not invent" rule.
