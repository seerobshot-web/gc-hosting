/**
 * SCAFFOLD ONLY — a Phase 10/11 starting point, not a finished adapter.
 *
 * This is the one genuine "webhook" in the whole system: Stripe calls this
 * endpoint directly over HTTPS. It is application code living in apps/api,
 * not something GitHub Actions triggers or schedules — do not confuse it
 * with the CI/CD workflows in .github/workflows/.
 *
 * Must be mounted with Express's raw-body parser for this route (or the
 * NestJS equivalent) BEFORE the JSON body parser runs, or signature
 * verification will fail. Still needed before this can be trusted:
 *  - an idempotency store keyed on event.id (in-memory is not enough)
 *  - real routing into the Phase 11 entitlement state machine
 *  - redaction of payment details before anything here is logged
 */

import { Controller, Post, Req, Res, Headers, HttpStatus } from '@nestjs/common';
import type { Request, Response } from 'express';
import Stripe from 'stripe';

@Controller('webhooks/stripe')
export class StripeWebhookController {
  private readonly stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
    apiVersion: '2024-06-20',
  });

  @Post()
  async handle(
    @Req() req: Request, // req.body must be the raw Buffer, not JSON-parsed
    @Res() res: Response,
    @Headers('stripe-signature') signature: string,
  ) {
    let event: Stripe.Event;

    try {
      event = this.stripe.webhooks.constructEvent(
        req.body,
        signature,
        process.env.STRIPE_WEBHOOK_SECRET!,
      );
    } catch (err) {
      // Fail closed: an unverifiable webhook is never trusted as payment authority.
      return res
        .status(HttpStatus.BAD_REQUEST)
        .send(`Webhook signature verification failed: ${(err as Error).message}`);
    }

    // TODO: idempotency — check event.id against a processed-events store
    // before acting, and record it afterward. Never process the same
    // event.id twice.

    switch (event.type) {
      case 'checkout.session.completed':
      case 'invoice.paid':
      case 'invoice.payment_failed':
        // TODO: forward to the Phase 11 orchestration/entitlement service.
        // GCH may record this event, but Stripe remains the payment
        // authority — "verified" can only come from this signed event or
        // a subsequent server-side retrieval call to Stripe, never from a
        // browser-side success callback.
        break;
      default:
        // Unhandled event types are acknowledged, not silently trusted.
        break;
    }

    return res.status(HttpStatus.OK).send({ received: true });
  }
}
